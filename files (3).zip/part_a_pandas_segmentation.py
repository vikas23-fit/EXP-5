"""
PART A - Build a customer dataset with Pandas, segment it, export to CSV.

Differences from the earlier version:
  * 120 customers instead of 100, IDs start at 1001
  * City (5 values) instead of Region (4 values)
  * Extra column: Purchase_Frequency (orders placed in the year)
  * FOUR spend tiers instead of three: Budget / Standard / Premium / Elite
  * Wider spend range (200 - 9000) and a different random seed
"""

import pandas as pd
import numpy as np

# ------------------------------------------------------------------
# Step 1: Create the sample customer dataset
# ------------------------------------------------------------------
np.random.seed(7)                      # different seed -> different data
N_CUSTOMERS = 120

data = {
    "Customer_ID": range(1001, 1001 + N_CUSTOMERS),
    "Age": np.random.randint(21, 66, N_CUSTOMERS),
    "Annual_Spend": np.random.randint(200, 9000, N_CUSTOMERS),
    "Purchase_Frequency": np.random.randint(1, 40, N_CUSTOMERS),
    "City": np.random.choice(
        ["Delhi", "Mumbai", "Bengaluru", "Chennai", "Kolkata"], N_CUSTOMERS
    ),
}
df = pd.DataFrame(data)

# ------------------------------------------------------------------
# Step 2: Segment the customers into four spending tiers
# ------------------------------------------------------------------
bins = [0, 1500, 3500, 6000, 9000]
labels = ["Budget", "Standard", "Premium", "Elite"]
df["Spend_Segment"] = pd.cut(df["Annual_Spend"], bins=bins, labels=labels)

# A second derived column: how much each customer spends per order
df["Avg_Order_Value"] = (df["Annual_Spend"] / df["Purchase_Frequency"]).round(2)

# ------------------------------------------------------------------
# Step 3: Export to CSV
# ------------------------------------------------------------------
df.to_csv("customer_tiers.csv", index=False)

print("Data successfully processed and exported to CSV!")
print(df.head(10).to_string(index=False))
print("\nCustomers per segment:")
print(df["Spend_Segment"].value_counts().reindex(labels).to_string())
