"""
PART B - Build a formatted Excel pivot table from the CSV, then draw the chart.

Differences from the earlier version:
  * Pivot is TRANSPOSED: Rows = City, Columns = Spend_Segment
  * Four segments and five cities
  * Chart is a HORIZONTAL STACKED BAR chart (customers per city, split by
    segment) instead of a plain vertical bar chart of segment totals
"""

import pandas as pd
import matplotlib.pyplot as plt
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

FONT = "Arial"
TEAL = "1F4E4A"
WHITE = "FFFFFF"
LIGHT_TEAL = "DCE9E6"
MID_TEAL = "BDD8D2"

df = pd.read_csv("customer_tiers.csv")
N = len(df)
LAST_ROW = N + 1

wb = Workbook()

# ============================================================
# Sheet 1: Data  (the CSV exported from Pandas)
# ============================================================
ws = wb.active
ws.title = "Data"
cols = list(df.columns)
ws.append(cols)
for r in df.itertuples(index=False):
    ws.append(list(r))

header_fill = PatternFill("solid", fgColor=TEAL)
header_font = Font(name=FONT, bold=True, color=WHITE, size=10)
for c in range(1, len(cols) + 1):
    cell = ws.cell(row=1, column=c)
    cell.fill = header_fill
    cell.font = header_font
    cell.alignment = Alignment(horizontal="center", wrap_text=True)

for row in ws.iter_rows(min_row=2, max_row=LAST_ROW, min_col=1, max_col=len(cols)):
    for cell in row:
        cell.font = Font(name=FONT, size=10)
for r in range(2, LAST_ROW + 1):
    ws.cell(row=r, column=3).number_format = '$#,##0'    # Annual_Spend
    ws.cell(row=r, column=7).number_format = '$#,##0.00' # Avg_Order_Value

widths = [12, 6, 14, 18, 12, 15, 16]
for i, w in enumerate(widths, start=1):
    ws.column_dimensions[get_column_letter(i)].width = w

tab = Table(displayName="CustomerData", ref=f"A1:{get_column_letter(len(cols))}{LAST_ROW}")
tab.tableStyleInfo = TableStyleInfo(name="TableStyleMedium7", showRowStripes=True)
ws.add_table(tab)
ws.freeze_panes = "A2"

DATA = "Data"
# Column order: A=Customer_ID, B=Age, C=Annual_Spend, D=Purchase_Frequency,
#               E=City, F=Spend_Segment, G=Avg_Order_Value
SPEND_COL = f"$C$2:$C${LAST_ROW}"
CITY_COL = f"$E$2:$E${LAST_ROW}"
SEG_COL = f"$F$2:$F${LAST_ROW}"

thin = Side(style="thin", color="BFBFBF")
border = Border(left=thin, right=thin, top=thin, bottom=thin)

# ============================================================
# Sheet 2: PivotTable  — Rows = City, Columns = Spend_Segment,
# Values = Count of Customer_ID AND Average of Annual_Spend
# ============================================================
wsp = wb.create_sheet("PivotTable")
wsp["A1"] = "Pivot Table: Customer Count & Average Spend by City and Segment"
wsp["A1"].font = Font(name=FONT, bold=True, size=14, color=TEAL)
wsp["A2"] = ("Rows = City | Columns = Spend_Segment | "
             "Values = Count of Customer_ID, Average of Annual_Spend")
wsp["A2"].font = Font(name=FONT, italic=True, size=9, color="808080")

cities = ["Bengaluru", "Chennai", "Delhi", "Kolkata", "Mumbai"]
segments = ["Budget", "Standard", "Premium", "Elite"]

header_row1 = 4    # segment names (merged across 2 cols each)
header_row2 = 5    # "Count" / "Average Spend" sub-headers
first_data_row = 6

wsp.cell(row=header_row1, column=1, value="City")
wsp.merge_cells(start_row=header_row1, start_column=1, end_row=header_row2, end_column=1)

col = 2
seg_start_col = {}
for seg in segments:
    seg_start_col[seg] = col
    wsp.cell(row=header_row1, column=col, value=seg)
    wsp.merge_cells(start_row=header_row1, start_column=col,
                    end_row=header_row1, end_column=col + 1)
    wsp.cell(row=header_row2, column=col, value="Count of Customer_ID")
    wsp.cell(row=header_row2, column=col + 1, value="Average of Annual_Spend")
    col += 2

grand_total_start_col = col
wsp.cell(row=header_row1, column=col, value="Grand Total")
wsp.merge_cells(start_row=header_row1, start_column=col,
                end_row=header_row1, end_column=col + 1)
wsp.cell(row=header_row2, column=col, value="Count of Customer_ID")
wsp.cell(row=header_row2, column=col + 1, value="Average of Annual_Spend")

last_col = col + 1
for r in (header_row1, header_row2):
    for c in range(1, last_col + 1):
        cell = wsp.cell(row=r, column=c)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

# ---- one row per city -------------------------------------------------
for i, city in enumerate(cities):
    r = first_data_row + i
    wsp.cell(row=r, column=1, value=city).font = Font(name=FONT, bold=True, size=10)
    wsp.cell(row=r, column=1).fill = PatternFill("solid", fgColor=LIGHT_TEAL)
    for seg in segments:
        c = seg_start_col[seg]
        cl = get_column_letter(c)
        wsp.cell(row=r, column=c,
                 value=f'=COUNTIFS({DATA}!{CITY_COL},$A{r},{DATA}!{SEG_COL},{cl}${header_row1})')
        wsp.cell(row=r, column=c + 1,
                 value=(f'=IFERROR(AVERAGEIFS({DATA}!{SPEND_COL},{DATA}!{CITY_COL},$A{r},'
                        f'{DATA}!{SEG_COL},{cl}${header_row1}),0)')
                 ).number_format = '$#,##0'
    wsp.cell(row=r, column=grand_total_start_col,
             value=f'=COUNTIF({DATA}!{CITY_COL},$A{r})')
    wsp.cell(row=r, column=grand_total_start_col + 1,
             value=f'=AVERAGEIFS({DATA}!{SPEND_COL},{DATA}!{CITY_COL},$A{r})'
             ).number_format = '$#,##0'

# ---- grand total row --------------------------------------------------
total_row = first_data_row + len(cities)
wsp.cell(row=total_row, column=1, value="Grand Total")
for seg in segments:
    c = seg_start_col[seg]
    cl = get_column_letter(c)
    wsp.cell(row=total_row, column=c,
             value=f'=COUNTIF({DATA}!{SEG_COL},{cl}${header_row1})')
    wsp.cell(row=total_row, column=c + 1,
             value=f'=AVERAGEIFS({DATA}!{SPEND_COL},{DATA}!{SEG_COL},{cl}${header_row1})'
             ).number_format = '$#,##0'
wsp.cell(row=total_row, column=grand_total_start_col, value=f'=COUNTA({DATA}!{SEG_COL})')
wsp.cell(row=total_row, column=grand_total_start_col + 1,
         value=f'=AVERAGE({DATA}!{SPEND_COL})').number_format = '$#,##0'

for c in range(1, last_col + 1):
    cell = wsp.cell(row=total_row, column=c)
    cell.font = Font(name=FONT, bold=True, size=10)
    cell.fill = PatternFill("solid", fgColor=MID_TEAL)

for r in range(header_row1, total_row + 1):
    for c in range(1, last_col + 1):
        wsp.cell(row=r, column=c).border = border
        if r >= first_data_row:
            wsp.cell(row=r, column=c).alignment = Alignment(horizontal="center")

wsp.column_dimensions["A"].width = 16
for c in range(2, last_col + 1):
    wsp.column_dimensions[get_column_letter(c)].width = 15
wsp.sheet_view.showGridLines = False

# Note the source of the numbers, as required for any generated workbook.
note_row = total_row + 2
wsp.cell(row=note_row, column=1,
         value=("Note: all figures are live formulas (COUNTIFS / AVERAGEIFS) reading the "
                "'Data' sheet. Source data is randomly generated in "
                "part_a_pandas_segmentation.py (numpy seed = 7)."))
wsp.cell(row=note_row, column=1).font = Font(name=FONT, italic=True, size=9, color="808080")

wb.save("Customer_Tiers_PivotTable.xlsx")
print("Workbook saved.")

# ============================================================
# Chart: HORIZONTAL STACKED BAR — customers per city, split by segment
# ============================================================
matrix = (
    df.pivot_table(index="City", columns="Spend_Segment",
                   values="Customer_ID", aggfunc="count", fill_value=0)
      .reindex(index=cities, columns=segments, fill_value=0)
)

colors = {"Budget": "#9DC3E6", "Standard": "#70AD47",
          "Premium": "#FFC000", "Elite": "#C0504D"}

fig, ax = plt.subplots(figsize=(10, 6), dpi=150)
left = [0] * len(cities)

for seg in segments:
    values = matrix[seg].tolist()
    bars = ax.barh(cities, values, left=left, height=0.62,
                   color=colors[seg], edgecolor="#404040",
                   linewidth=0.7, label=seg)
    # label each block that is wide enough to hold text
    for bar, v, l in zip(bars, values, left):
        if v >= 2:
            ax.text(l + v / 2, bar.get_y() + bar.get_height() / 2, str(v),
                    ha="center", va="center", fontsize=9,
                    fontweight="bold", color="#1A1A1A")
    left = [l + v for l, v in zip(left, values)]

# total at the end of each bar
for y, total in enumerate(left):
    ax.text(total + 0.4, y, f"n = {total}", va="center",
            fontsize=9, fontweight="bold", color="#404040")

ax.set_title("Customer Spend Tiers by City (Stacked)",
             fontsize=14, fontweight="bold", pad=14)
ax.set_xlabel("Number of Customers", fontsize=11)
ax.set_ylabel("City", fontsize=11)
ax.set_xlim(0, max(left) * 1.16)
ax.grid(axis="x", linestyle="--", linewidth=0.7, alpha=0.5)
ax.set_axisbelow(True)
ax.invert_yaxis()
ax.legend(title="Spend Segment", loc="upper center", bbox_to_anchor=(0.5, -0.13),
          ncol=len(segments), frameon=False, fontsize=10)

fig.tight_layout()
fig.savefig("customer_tiers_stacked_bar.png", dpi=300, bbox_inches="tight")
print("Chart saved.")
